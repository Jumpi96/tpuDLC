1) La BD debe incluirse en la carpeta del servidor (ej. ...\glassfish-4.1.1\glassfish\domains\domain1\config).
La BD comprimida se encuentra en el siguiente link:
https://drive.google.com/open?id=0B4ZEgf4eF3LeSURJY3A4bDRaRFU
2) Para poder ser redirigido directamente al archivo, se puede editar el archivo Configuracion.properties incluyendo la ubicación de los archivos en el atributo "archivos".
